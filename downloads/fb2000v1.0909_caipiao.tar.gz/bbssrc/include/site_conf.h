/* include/site_conf.h.  Generated automatically by configure.  */
/*
CVS: $Id: site_conf.h.in,v 1.1.1.1 2000/08/25 14:20:33 deardragon Exp $
*/
#ifndef _AUTOCONFIG_H_
#define _AUTOCONFIG_H_

#define HAVE_STRFTIME 	0
#define HAVE_LIBCRYPT 	0
#define HAVE_LIBTERMCAP 1
#define HAVE_MMAP 		0
#define HAVE_RSTAT		0
#define HAVE_GETLOADAVG	0

#endif
