#include <sys/stat.h>
#include <stdio.h>
#include "../../include/bbs.h"
#include <time.h>


int
main ()
{
	int i, num[4], m = 0, n = 0, o = 0, p = 0,m1=0,n1=0,o1=0, k, j,t;
	long int money,oldmoney,count;
	char cmd[256],piao[5],oldpiao[5], *buffer, *a, *man, datestring[15], tmp[256],
		tmp1[256], anum[4001];
	FILE *fp,*fp2;
	struct stat stats;
	struct timeval tv;
	struct tm *tm;
	time_t now;
	
	gettimeofday(&tv,NULL);
	srand ((unsigned) (time (NULL)+tv.tv_usec+1324)); /*you can change 1324 to other number for better safe*/
	for (i = 0; i < 4; i++)
		num[i] = rand () % 10;
	sprintf (piao, "%d%d%d%d", num[0], num[1], num[2], num[3]);
	
	if ((fp = fopen ("/home/bbs/game/caipiao.oldbuyman", "r")) != NULL)
	{
		while (!feof (fp))
		{
			fscanf (fp, "%s\n", tmp);
			if (tmp[0] == ' ')
				continue;
			sprintf (cmd, "rm -f /home/bbs/home/%c/%s/number.old",
				 toupper (tmp[0]), tmp);
			system(cmd);
		}
		fclose(fp);
		system("rm -f /home/bbs/game/caipiao.oldbuyman");
	}
	if ((fp = fopen ("/home/bbs/game/caipiao.buyman", "r")) != NULL)
	{
		while (!feof (fp))
		{
			fscanf (fp, "%s\n", tmp);
			if (tmp[0] == ' ')
				continue;
			sprintf (tmp1, "/home/bbs/home/%c/%s/number",
				 toupper (tmp[0]), tmp);
			if ((fp2 = fopen (tmp1, "r")) != NULL)
			{
				fgets (anum, 4001, fp2);
				fclose (fp2);
				p = 0;
				for (k = 0; k < strlen (anum) / 4; k++)
				{
					t = 0;
					for (j = 0; j < 4; j++)
					{
						if (piao[j] == anum[j +( k * 4)])
							t++;
					}
					if (t > 1)
						p++;
					switch (t)
					{
					case 4:
					{
						m++;
						break;
					}
					case 3:
					{
						n++;
						break;
					}
					case 2:
					{
						o++;
						break;
					}
					}
				}
				if (p > 0)
				{
					/*mail_file("etc/zhongjiang",tmp,"zhongjiang");	*/
				}
			}

			sprintf (cmd, "mv -f %s %s.old", tmp1, tmp1);
			system (cmd);
		}
		fclose (fp);

		system ("mv -f /home/bbs/game/caipiao.buyman /home/bbs/game/caipiao.oldbuyman");
	}
        if ((fp = fopen ("/home/bbs/game/caipiao.jiangcount", "r")) != NULL)
	{
		fscanf(fp,"%d %d %d",&m1,&n1,&o1);
		fclose(fp);
	}
	else
	{
		m1=0;n1=0;o1=0;
	}
        if ((fp = fopen ("/home/bbs/game/caipiao.jiangcount", "w")) != NULL)
	{
		fprintf(fp,"%d %d %d",m,n,o);
		fclose(fp);
	}
        if ((fp = fopen ("/home/bbs/game/caipiao.oldmoney", "r")) != NULL)
	{
		fscanf (fp, "%d", &oldmoney);
		fclose (fp);
		system("rm -f /home/bbs/game/caipiao.oldmoney");
	}
        if ((fp = fopen ("/home/bbs/game/caipiao.money", "r")) != NULL)
	{
		fscanf (fp, "%d", &money);
		fclose (fp);
		sprintf(cmd,"mv -f /home/bbs/game/caipiao.money /home/bbs/game/caipiao.oldmoney");
		system(cmd);
	}
	else
	{
		sprintf (cmd, "echo 200000 > /home/bbs/game/caipiao.oldmoney");
		system(cmd);
		money=200000;
	}
	if (m==0)
	{
		money+=200000;
		if (money>9800000)
			money=9800000;
	}
	else
	{
		money=200000;
	}
	sprintf(cmd,"echo %d > /home/bbs/game/caipiao.money",money);
	system(cmd);

	
	time (&now);
	tm = localtime (&now);
	sprintf (datestring, "%4d��%02d��%02d��",
		 tm->tm_year + 1900, tm->tm_mon + 1, tm->tm_mday);
        oldpiao[0]='\0';
	buffer = NULL;
	man = NULL;
	if ((fp = fopen ("/home/bbs/game/caipiao", "r")) != NULL)
	{
		fgets (oldpiao, 5, fp);
		fclose (fp);
	}
	sprintf (cmd, "echo %s > /home/bbs/game/caipiao ", piao);
	system (cmd);
	if (lstat ("/home/bbs/game/caipiao.log", &stats) != -1)
	{
		if ((fp = fopen ("/home/bbs/game/caipiao.log", "r")) != NULL)
		{
			buffer = malloc (stats.st_size + 1);
			if (fread (buffer, 1, stats.st_size, fp) !=
			    stats.st_size)
			{
				free (buffer);
				buffer = NULL;
			}
			fclose (fp);
			buffer[stats.st_size] = '\0';
		}
	}
	if (lstat ("/home/bbs/game/caipiao.man", &stats) != -1)
	{
		if ((fp = fopen ("/home/bbs/game/caipiao.man", "r")) != NULL)
		{
			man = malloc (stats.st_size + 1);
			if (fread (man, 1, stats.st_size, fp) !=
			    stats.st_size)
			{
				free (man);
				man = NULL;
			}
			fclose (fp);
			man[stats.st_size] = '\0';
			system ("rm -f /home/bbs/game/caipiao.man");
		}
	}
	if ((fp = fopen ("/home/bbs/game/caipiao.oldcount", "r")) != NULL)
	{
		fscanf (fp, "%d", &count);
		fclose (fp);
		system("rm -f /home/bbs/game/caipiao.oldcount");
	}
	else
		count=0;
	if (lstat ("/home/bbs/game/caipiao.count", &stats) != -1)
	{
		system("mv -f /home/bbs/game/caipiao.count /home/bbs/game/caipiao.oldcount");
	}
	if ((fp = fopen ("/home/bbs/game/caipiao.log", "w")) != NULL)
	{
		fprintf (fp, "%s",
			 "�������������������������������������������������������������\n                            �����Ʊ���ڲ�Ʊ�����б�\n�������������������������������������������������������������\n[1;33;44m ��Ʊ����  һ�Ƚ�����      ����ʱ��      ����  ���Ƚ�   ���Ƚ�   һ�Ƚ�����     [m\n");
		if (buffer)
		{
			a = buffer + 309;
			for (i = 0; i < 17; i++)
			{
				while ((*a != '\n') && (*a != '\0'))
					a++;
				if (*(a + 1) != '\0')
					a++;
			}
			*a = '\0';
			if (oldpiao[0] != '\0')
				if (!man)
					fprintf (fp,
						 "   %s     %7d     %s %6d   %3d     %4d      �����в�\n",
						 oldpiao,oldmoney,datestring,count,n1,o1);
				else
					fprintf (fp, "   %s     %7d     %s %6d   %3d     %4d     %s\n", oldpiao,oldmoney,
						 datestring,count,n1,o1, man);
			fprintf (fp, "%s", buffer + 309);
		}
		fclose (fp);
		if (man) free (man);
		if (buffer) free (buffer);
	}

}
