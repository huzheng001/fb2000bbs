#ifndef INNBBSD_H
#define INNBBSD_H
#include "daemon.h"

#ifndef ADMINUSER
# define ADMINUSER "SYSOP.bbs@MSIA.pine.ncu.edu.tw"
#endif

#endif
